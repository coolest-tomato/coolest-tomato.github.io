```python
import numpy as np
import matplotlib.pyplot as plt
import math
```


```python
# parameters for v(x) 
pho1 = 0.2         # volume charge density 
pho2 = 0.1
pho3 = 0.05
pho4 = 0.01
# if pho increases, shape is getting more sharp
er = 3.8        # SiO2 permittivity
e0 = 8.854e-12
e  = e0 * er 
distance = 100e-6 # distance between plates 
V_0 = 5 # 5 volts at x = 0
V_d = 0 # ground at x = distance
```


```python
def potential_pho1(x, C1, C2):
    return -(pho1/(2*e))*(x**2) + C1*x + C2 
def potential_pho2(x, C1, C2):
    return -(pho2/(2*e))*(x**2) + C1*x + C2
def potential_pho3(x, C1, C2):
    return -(pho3/(2*e))*(x**2) + C1*x + C2
def potential_pho4(x, C1, C2):
    return -(pho4/(2*e))*(x**2) + C1*x + C2
C2 = 5
C1 = (p*d)/(2*e) - (5/d) # pho1,2,3,4 -> Fixing codes in a simpler way 
```


```python
x = np.linspace(0, d, 500)
```


```python
# Making subplot for four values of rho 
figure, axis = plt.subplots(2, 2, figsize=(10, 8), constrained_layout=True)

axis[0, 0].plot(x, potential_pho1(x, C1, C2))
axis[0, 0].set_title("pho = 0.2")
axis[0, 1].plot(x, potential_pho2(x, C1, C2))
axis[0, 1].set_title("pho = 0.1")
axis[1, 0].plot(x, potential_pho3(x, C1, C2))
axis[1, 0].set_title("pho = 0.05")
axis[1, 1].plot(x, potential_pho4(x, C1, C2))
axis[1, 1].set_title("pho = 0.01")

plt.show()
```


    
![png](output_4_0.png)
    



```python

```
